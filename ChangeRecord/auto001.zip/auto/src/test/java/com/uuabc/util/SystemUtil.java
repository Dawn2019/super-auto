package com.uuabc.util;

import java.io.InputStream;
import java.util.Map;
import java.util.Properties;

public class SystemUtil {
	private static String url = null;
	private static String driver = null;
	private static String Add = null;
	
	public static Map getSystem () {
		try {
			Map<String,String> map =null;
			Properties props = new Properties();
			InputStream in = SystemUtil.class.getClassLoader().getResourceAsStream("System.properties");
			props.load(in);
			url = props.getProperty("url");
			driver = props.getProperty("driver");
			Add = props.getProperty("Add");
			map.put("url", url);
			map.put("driver", driver);
			map.put("Add", Add);
			return map;
		}catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new RuntimeException(e);
	}
	}
}
